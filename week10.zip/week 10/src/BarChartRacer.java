import java.util.Arrays;

public class BarChartRacer {
    public static void main(String[] args) {
        //reads in the comand line arguments
        int count = Integer.parseInt(args[1]);
        In in = new In(args[0]);
        //grabs the first three lines of the txt doc to great the heading
        //xaxis and sources
        String title = in.readLine();
        String xAxis = in.readLine();
        String source = in.readLine();
        //creats a variable to use the barchart function with
        BarChart chart = new BarChart(title, xAxis, source);
        //creats the canvas size
        StdDraw.setCanvasSize(1000, 700);
        StdDraw.enableDoubleBuffering();
        //this section reads in the txt doc as long as its not empoty
        while (in.hasNextLine()) {
            //clears the canvas to be redrawn
            StdDraw.clear();
            //reads the empty line
            String s = in.readLine();
            //tells how many lines there are to read
            int n = Integer.parseInt(in.readLine());
            // creats the bar variable for the Bar function to be used
            Bar[] bar = new Bar[n];

            for (int i = 0; i < n; i++) {
                String line = in.readLine();
                String[] array = line.split(",");
                String v = array[3];
                int value = Integer.parseInt(v);

                //creats new bar for each line
                bar[i] = new Bar(array[1], value, array[4]);
                chart.setCaption(array[0]);

            }
            Arrays.sort(bar);//sorts bars
            //displays the bars greater than 0 and adds them to the BarChart object
            if (bar[bar.length - count].getValue() > 0) {
                for (int i = (bar.length - 1); i >= (bar.length - count); i--) {
                    chart.add(bar[i].getName(), bar[i].getValue(), bar[i].getCategory());

                }

                chart.draw();
                StdDraw.show();
                StdDraw.pause(35);
                chart.reset();
            }

        }
    }
}
